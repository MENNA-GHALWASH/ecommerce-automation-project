import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class automation {

    WebDriver driver = new ChromeDriver();
    loginSteps Ls = new loginSteps(driver);


@BeforeTest
public void openAndNavigate() {
    System.setProperty("webdriver.chrome.driver","C:\\Users\\Kimo\\Downloads\\chromedriver_win32\\chromedriver.exe");
    // driver = new ChromeDriver();
    driver.navigate().to("https://www.amazon.com/");
    driver.manage().window().maximize();
}
@Test
    public void validEntry() throws InterruptedException {
/*    driver.navigate().to("https://www.amazon.eg/-/en/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.eg%2F%3F%26tag%3Degtxabkgode-21%26ref%3Dnav_ya_signin%26adgrpid%3D123528178741%26hvpone%3D%26hvptwo%3D%26hvadid%3D593152336207%26hvpos%3D%26hvnetw%3Dg%26hvrand%3D9796602087189701647%26hvqmt%3De%26hvdev%3Dc%26hvdvcmdl%3D%26hvlocint%3D%26hvlocphy%3D1005386%26hvtargid%3Dkwd-10573980%26hydadcr%3D334_2589534%26gclid%3DEAIaIQobChMIsO7-39j5-wIVxuzVCh0eLwXxEAAYASAAEgKLj_D_BwE%26language%3Den_AE&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=egflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
    driver.manage().window().maximize();*/
    Ls.user_email("mennakmg@gmail.com");
    Ls.password("Menno2812");
    }
@Test
    public void chooseBag() throws InterruptedException {
    driver.navigate().to("https://www.amazon.eg/?&tag=egtxabkgode-21&ref=pd_sl_7p2aq4fe2v_e&adgrpid=123528178741&hvpone=&hvptwo=&hvadid=593152336207&hvpos=&hvnetw=g&hvrand=792968547175342&hvqmt=e&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=1005386&hvtargid=kwd-10573980&hydadcr=334_2589534&gclid=EAIaIQobChMIn-Llp-_5-wIVYvbVCh2pfAsGEAAYASAAEgKG0PD_BwE&language=en_AE");
    Ls.search_for_item("bag");
    Ls.shop();
    Thread.sleep(2000);
    String Actres = Ls.shoppingCartRes();
    Assert.assertEquals(Actres," Added to Cart");
    Ls.deleteItem();
    Ls.deleteMsG();
    String actdeletemsg=Ls.deleteMsG();
    String deleting_mssg= "OZUKO 9338 Waterproof Leather Crossbody Bag For Travel - Grey was removed from Shopping Cart";
    Assert.assertEquals(actdeletemsg,deleting_mssg);
}
@Test
public void invalidEntry(){
    Ls.user_email(" fgfvw");
    String problemmsg = driver.findElement(By.cssSelector("h4[class=\"a-alert-heading\"]")).getText();
    Assert.assertEquals(problemmsg,"There was a problem");
    Ls.password("kkbll");
    Assert.assertEquals(problemmsg,"There was a problem");
}
@Test
public void changeCurrency(){
    driver.findElement(By.cssSelector("[class=\"nav-icon nav-arrow\"]")).click();
    //driver.findElement(By.className("a-dropdown-prompt")).click();
    String act = driver.findElement(By.id("icp-currency-subheading")).getText();
    String exp = "Select the currency you want to shop with.";
    Assert.assertEquals(act,exp);
    //driver.findElement(By.className("a-button-input")).click();
}
@Test
public void selectcat(){
    driver.findElement(By.id("nav-hamburger-menu")).click();
    String act = driver.findElement(By.cssSelector("[class=\"hmenu-item hmenu-title \"]")).getText();
    //String act = driver.fi.getText();
    String exp = "Digital Content & Devices";
    Assert.assertEquals(act,exp);
}
@AfterTest
    public void closedriver(){driver.quit();}


}
