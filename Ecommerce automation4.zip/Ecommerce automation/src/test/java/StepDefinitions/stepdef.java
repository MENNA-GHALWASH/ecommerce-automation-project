package StepDefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import java.util.Scanner;

public class stepdef {
    WebDriver driver = new ChromeDriver();
    loginSteps Ls = new loginSteps(driver);

    //Scanner s =new Scanner(System.in);
    String Username,Password;
    //!! note to reviewer!!
//please use your username and password to sign in by intitializing above variables

    @Before
    public void openBrowser(){
        System.setProperty("webdriver.chrome.driver","C:\\Users\\Kimo\\Downloads\\chromedriver_win32\\chromedriver.exe");
        // driver = new ChromeDriver();
        driver.navigate().to("https://www.amazon.com/");
        //driver.navigate().to("https://www.amazon.eg/-/en/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.eg%2F%3F%26tag%3Degtxabkgode-21%26ref%3Dnav_ya_signin%26adgrpid%3D123528178741%26hvpone%3D%26hvptwo%3D%26hvadid%3D593152336207%26hvpos%3D%26hvnetw%3Dg%26hvrand%3D9796602087189701647%26hvqmt%3De%26hvdev%3Dc%26hvdvcmdl%3D%26hvlocint%3D%26hvlocphy%3D1005386%26hvtargid%3Dkwd-10573980%26hydadcr%3D334_2589534%26gclid%3DEAIaIQobChMIsO7-39j5-wIVxuzVCh0eLwXxEAAYASAAEgKLj_D_BwE%26language%3Den_AE&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=egflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
        driver.manage().window().maximize();
    }

    @Given("that his email isn't taken")
    public void createAcount() throws InterruptedException {
        driver.findElement(By.id("nav-link-accountList-nav-line-1")).click();
        Ls.createNewAccount("ABC","Abc@gmail.com","far3s5647");
    }
//should i remove this And?
    @Given("that his email and password are correct")
    @And("he is logged in")
    public void validentry() throws InterruptedException {
        driver.findElement(By.id("nav-link-accountList-nav-line-1")).click();
        //!!Note to reviewer!!
        //please initialize the below variables
        Username ="Abc@gmail.com";
        //Password = "far3s5647";
        Ls.user_email(Username);
        //Ls.password(Password);
        String act = driver.findElement(By.id("signInSubmit")).getText();
        String exp = "Sign in";
        Assert.assertEquals(act,exp);
        Thread.sleep(2000);
    }

    @Given("user clicked on forgot password")
    public void changepsswrd(){
        driver.findElement(By.id("nav-link-accountList-nav-line-1")).click();
        //!!Note to reviewer!!
        //please initialize the below variables
        Username ="Abc@gmail.com";//write personal username
        Ls.user_email(Username);
        driver.findElement(By.id("auth-fpp-link-bottom")).click();
        //   driver.findElement(By.id("ap_email")).sendKeys(Username);
       // driver.findElement(By.id("continue")).click();
    }

    @Then("user recieves the email message")
    public void forgotpsswrdmessage(){
        String expres="To continue, complete this verification step. we’ve sent a code to your email mennakmg@gmail.com. Please enter it below.";
        String actres = driver.findElement(By.className("a-row a-spacing-none")).getText();

        Assert.assertEquals(expres,actres);
    }

    @Given("he clicked on the currency")
    public void changeCurrency(){
        driver.findElement(By.cssSelector("[class=\"nav-icon nav-arrow\"]")).click();
        //driver.findElement(By.className("a-dropdown-prompt")).click();
        String act = driver.findElement(By.id("icp-currency-subheading")).getText();
        String exp = "Select the currency you want to shop with.";
        Assert.assertEquals(act,exp);
        //driver.findElement(By.className("a-button-input")).click();
    }

    @Given("he selected category")
    public void selectcat(){
        driver.findElement(By.id("nav-hamburger-menu")).click();
        String act = driver.findElement(By.cssSelector("[class=\"hmenu-item hmenu-title \"]")).getText();
        String exp = "Digital Content & Devices";
        Assert.assertEquals(act,exp);
    }

    @Given("that he types it in the search bar and it exists")
    public void searchproduct(){
        Ls.search_for_item("bag");
        Ls.shop();
    }

    @Given("he views a product")
    public void View() {
        Ls.search_for_item("bag");
        Ls.shop();
       // driver.findElement(By.id("add-to-cart-button")).click();
    }
    @And ("puts in in cart")
    public void addtocart(){
        driver.findElement(By.id("add-to-cart-button")).click();

    }


    @And("wont buy it now")
    public void wishlist(){
       driver.findElement(By.className("nav-line-2")).click();
       driver.findElement(By.name("submit.save-for-later.C0bd50e41-8d45-47cd-96e2-4d8c66944cbb")).click();
       String act = driver.findElement(By.id("sc-saved-cart-list-caption-text")).getText();
       String exp = "Saved for later (1 item)";
       Assert.assertEquals(act,exp);
    }

//    @And("wants the cheaper one")
//    public void comparelist(){

    //} no compare list in amazon

    @And ("color option exists")
    public boolean chooseColor(){
        if(driver.findElement(By.cssSelector("[class=\"a-unordered-list a-nostyle a-button-list a-declarative a-button-toggle-group a-horizontal dimension-values-list\"]")).getText()=="Color")
            return true;
        return false;
    }

    @And("buys the product")
    public void buy(){
        driver.findElement(By.id("buy-now-button")).click();
        String act = driver.findElement(By.className("a-spacing-small")).getText();
        String exp = driver.findElement(By.tagName("h1")).getText();
        Assert.assertEquals(act,exp);
    }


    @After
    public void closebrwr(){
        driver.quit();
    }

}
